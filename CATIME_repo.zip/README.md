# CATIME V7.0 · 梦幻时光

Python/Tkinter 桌面时钟与计时器，主要面向 Windows 10/11。

## 功能
- 实时时钟、倒计时、番茄钟、秒表与计次
- 快捷计时预设、每日闹钟
- 透明窗口、窗口置顶、无边框拖动
- 四套主题、字号与颜色设置
- 动态星空：星星闪烁漂移、月亮往返移动
- 自定义底部星空区域背景图片（PNG/JPG/GIF/BMP）
- Windows 系统托盘：隐藏、恢复或退出
- Windows 当前用户开机启动
- 配置保存到 `%APPDATA%/CATIME/settings.json`

## 安装与运行
需要 Python 3.10+：
```bash
python -m pip install -r requirements.txt
python main.py
```

## 打包 EXE
在 Windows 双击 `build_windows.bat`，生成 `dist/CATIME.exe`（单文件）。也可推送到 GitHub，由 Actions 自动构建，在 Artifacts 下载。

## 快捷键
- 空格：开始/暂停
- R：重置

## 注意
- 自定义图片显示在底部动态星空区域，不会覆盖整个窗口。
- 系统托盘依赖 Pillow 与 pystray，仅在 Windows 启用。
- 当前环境不是 Windows，需在 Windows 10/11 真机测试托盘和 EXE。
