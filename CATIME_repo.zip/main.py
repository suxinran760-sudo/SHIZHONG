"""CATIME V5 - dreamy desktop clock with animated pixel-like starfield."""
from __future__ import annotations
import json, os, time, sys, random
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, colorchooser, simpledialog, filedialog

APP_NAME = "CATIME"
BASE = Path(os.environ.get("APPDATA", str(Path.home()))) / "CATIME"
BASE.mkdir(parents=True, exist_ok=True)
CONFIG = BASE / "settings.json"
DEFAULTS = {
    "accent": "#c2a7ff", "text": "#f4efff", "bg": "#17152b", "theme": "星夜紫", "startup": False,
    "alpha": 0.96, "topmost": True, "borderless": False, "moon_motion": True,
    "font": "Segoe UI", "font_size": 38,
    "work_min": 25, "short_min": 5, "long_min": 15,
    "auto_start_break": False, "sound": True, "wallpaper": "", "tray_enabled": True, "presets": [
        {"name": "快速休息", "minutes": 5}, {"name": "专注 25 分钟", "minutes": 25},
        {"name": "深度工作", "minutes": 50}
    ], "alarms": []
}

def load_config():
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        merged = {**DEFAULTS, **data}
        if not isinstance(merged.get("presets"), list): merged["presets"] = DEFAULTS["presets"].copy()
        if not isinstance(merged.get("alarms"), list): merged["alarms"] = []
        return merged
    except Exception:
        return DEFAULTS.copy()

def save_config(data):
    CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

THEMES = {
    "星夜紫": {"bg":"#17152b", "text":"#f4efff", "accent":"#c2a7ff"},
    "深海蓝": {"bg":"#101d30", "text":"#eaf5ff", "accent":"#72c8ff"},
    "森林绿": {"bg":"#14251f", "text":"#effff5", "accent":"#8fe0b2"},
    "暖阳橙": {"bg":"#2b1c19", "text":"#fff2e8", "accent":"#ffb47e"},
}

def set_windows_startup(enabled):
    """Register/unregister this app in the current user's Windows Run key."""
    if sys.platform != "win32":
        return False
    import winreg
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
        if enabled:
            exe = sys.executable if getattr(sys, "frozen", False) else sys.executable
            script = sys.argv[0]
            command = f'"{exe}"' if getattr(sys, "frozen", False) else f'"{exe}" "{os.path.abspath(script)}"'
            winreg.SetValueEx(key, "CATIME", 0, winreg.REG_SZ, command)
        else:
            try: winreg.DeleteValue(key, "CATIME")
            except FileNotFoundError: pass
    return True

class Catime:
    def __init__(self, root):
        self.root = root; self.cfg = load_config()
        self.mode = "clock"; self.remaining = 0; self.running = False; self.deadline = None
        self.sw_elapsed = 0.0; self.sw_started = None; self.laps = []
        self.pomo_phase = "专注"; self.pomo_round = 0; self.drag = (0, 0)
        self.alarm_fired = set(); self.last_minute = None
        self.star_phase = 0; self.stars = []; self.moon_x = 30; self.moon_dir = 1
        self.wallpaper_image = None; self.wallpaper_cache_key = None; self.tray_icon = None; self.tray_thread = None
        self._apply_window(); self._build(); self._bind_drag(self.root)
        self.root.bind_all("<space>", self._hotkey_space)
        self.root.bind_all("<KeyPress-r>", self._hotkey_reset)
        self.tick()

    def _apply_window(self):
        self.root.title("CATIME V7.0 · 梦幻时光"); self.root.geometry("470x340+160+140"); self.root.minsize(380, 310)
        self.root.configure(bg=self.cfg["bg"]); self.root.attributes("-topmost", self.cfg["topmost"])
        try: self.root.attributes("-alpha", self.cfg["alpha"])
        except tk.TclError: pass
        self.root.overrideredirect(self.cfg["borderless"])

    def _build(self):
        self.bg=self.cfg["bg"]; self.fg=self.cfg["text"]; self.accent=self.cfg["accent"]
        self.outer=tk.Frame(self.root,bg=self.bg,padx=22,pady=14); self.outer.pack(fill="both",expand=True)
        top=tk.Frame(self.outer,bg=self.bg); top.pack(fill="x")
        tk.Label(top,text="✦ CATIME  V6.0",bg=self.bg,fg=self.accent,font=(self.cfg["font"],11,"bold")).pack(side="left")
        self.status=tk.Label(top,text="● READY",bg=self.bg,fg="#8cdbbf",font=(self.cfg["font"],8)); self.status.pack(side="left",padx=10)
        self._button(top,"托盘",self.minimize_to_tray).pack(side="right",padx=4)
        self._button(top,"铃声",self.alarms).pack(side="right",padx=4)
        self._button(top,"预设",self.presets).pack(side="right",padx=4)
        self._button(top,"⚙",self.settings).pack(side="right",padx=4)
        self._button(top,"×",self.close).pack(side="right",padx=4)
        self.display=tk.Label(self.outer,text="00:00:00",bg=self.bg,fg=self.fg,font=(self.cfg["font"],self.cfg["font_size"],"bold"),pady=12)
        self.display.pack(fill="x")
        self.sub=tk.Label(self.outer,text="DREAM IN TIME",bg=self.bg,fg="#9b91b9",font=(self.cfg["font"],10)); self.sub.pack()
        tabs=tk.Frame(self.outer,bg=self.bg); tabs.pack(pady=(16,9))
        self.mode_buttons={}
        for label,mode in [("时钟","clock"),("倒计时","countdown"),("番茄钟","pomo"),("秒表","stopwatch")]:
            b=tk.Button(tabs,text=label,command=lambda m=mode:self.switch_mode(m),bg="#443866" if self.mode==mode else "#292541",fg=self.fg,activebackground="#514477",activeforeground="white",bd=0,padx=18,pady=7,cursor="hand2",font=(self.cfg["font"],9))
            b.pack(side="left",padx=4); self.mode_buttons[mode]=b
        controls=tk.Frame(self.outer,bg=self.bg); controls.pack()
        self.start_btn=tk.Button(controls,text="开始",command=self.start_pause,bg=self.accent,fg="#171329",activebackground="#d3c5ff",bd=0,padx=25,pady=8,cursor="hand2",font=(self.cfg["font"],10,"bold")); self.start_btn.pack(side="left",padx=5)
        self._button(controls,"重置",self.reset,padx=20,pady=8).pack(side="left",padx=5)
        self.lap_btn=self._button(controls,"计次",self.record_lap,padx=14,pady=8)
        self._button(controls,"设置时间",self.set_duration,padx=14,pady=8).pack(side="left",padx=5)
        quick=tk.Frame(self.outer,bg=self.bg); quick.pack(pady=(12,0))
        tk.Label(quick,text="快捷计时",bg=self.bg,fg="#81789f",font=(self.cfg["font"],8)).pack(side="left",padx=(0,5))
        for mins in (5,10,15,25,45,60):
            self._button(quick,f"{mins}分",lambda m=mins:self.quick_countdown(m),padx=7,pady=4).pack(side="left",padx=2)
        tk.Label(self.outer,text="空格：开始/暂停    R：重置    拖动窗口可移动",bg=self.bg,fg="#71698d",font=(self.cfg["font"],8)).pack(side="bottom",pady=(6,0))
        self.star_canvas=tk.Canvas(self.outer,height=58,bg=self.bg,bd=0,highlightthickness=0)
        self.star_canvas.pack(side="bottom",fill="x",pady=(8,0))
        self._init_stars()
        self._refresh_mode_buttons()

    def _draw_wallpaper(self, width, height):
        path = self.cfg.get("wallpaper", "")
        if not path or not os.path.isfile(path): return
        key = (path, width, height, os.path.getmtime(path))
        try:
            if self.wallpaper_cache_key != key:
                from PIL import Image, ImageTk
                image = Image.open(path).convert("RGB")
                ratio = max(width / image.width, height / image.height)
                image = image.resize((int(image.width*ratio), int(image.height*ratio)), Image.Resampling.LANCZOS)
                left=max(0,(image.width-width)//2); top=max(0,(image.height-height)//2)
                image=image.crop((left,top,left+width,top+height))
                self.wallpaper_image=ImageTk.PhotoImage(image)
                self.wallpaper_cache_key=key
            self.star_canvas.create_image(0,0,image=self.wallpaper_image,anchor="nw",tags="sky")
        except Exception: self.wallpaper_image=None

    def choose_wallpaper(self):
        path=filedialog.askopenfilename(parent=self.root,title="选择星空背景图片",filetypes=[("图片文件","*.png *.jpg *.jpeg *.gif *.bmp")])
        if not path: return
        try:
            from PIL import Image
            with Image.open(path) as im: im.verify()
            self.cfg["wallpaper"]=path; self.wallpaper_cache_key=None; save_config(self.cfg)
        except ImportError:
            messagebox.showerror("缺少组件","请运行 python -m pip install Pillow",parent=self.root)
        except Exception as exc: messagebox.showerror("图片无法使用",str(exc),parent=self.root)

    def clear_wallpaper(self):
        self.cfg["wallpaper"]=""; self.wallpaper_image=None; self.wallpaper_cache_key=None; save_config(self.cfg)

    def minimize_to_tray(self):
        if sys.platform != "win32":
            messagebox.showinfo("系统托盘","系统托盘功能目前仅支持 Windows。",parent=self.root); return
        try:
            import pystray
            from PIL import Image, ImageDraw
            if self.tray_icon is None:
                icon_image=Image.new("RGBA",(64,64),(23,21,43,255)); draw=ImageDraw.Draw(icon_image)
                draw.ellipse((14,10,50,46),fill=(194,167,255,255)); draw.ellipse((24,6,56,38),fill=(23,21,43,255))
                menu=pystray.Menu(pystray.MenuItem("显示 CATIME",lambda icon,item:self.root.after(0,self.restore_window)),pystray.MenuItem("退出",lambda icon,item:self.root.after(0,self.close_from_tray)))
                self.tray_icon=pystray.Icon("CATIME",icon_image,"CATIME 梦幻时光",menu)
                self.tray_thread=__import__("threading").Thread(target=self.tray_icon.run,daemon=True); self.tray_thread.start()
            self.root.withdraw()
        except ImportError:
            messagebox.showerror("缺少组件","系统托盘需要 Pillow 和 pystray。请运行：python -m pip install Pillow pystray",parent=self.root)
        except Exception as exc: messagebox.showerror("托盘启动失败",str(exc),parent=self.root)

    def restore_window(self):
        self.root.deiconify(); self.root.lift(); self.root.attributes("-topmost",self.cfg.get("topmost",True))

    def close_from_tray(self):
        if self.tray_icon:
            try: self.tray_icon.stop()
            except Exception: pass
            self.tray_icon=None
        self.close()

    def _init_stars(self):
        self.star_canvas.update_idletasks()
        width=max(300,self.star_canvas.winfo_width())
        rng=random.Random(2026)
        self.stars=[(rng.randrange(8,width-8),rng.randrange(5,54),rng.choice((1,1,2)),rng.random()*6.28,rng.choice((-.45,-.25,.25,.45))) for _ in range(42)]
        self.moon_x=35
        self._animate_stars()

    def _animate_stars(self):
        if not self.root.winfo_exists(): return
        self.star_phase += 1
        self.star_canvas.delete("sky")
        w=max(300,self.star_canvas.winfo_width()); h=max(58,self.star_canvas.winfo_height())
        self._draw_wallpaper(w, h)
        # A softly drifting crescent moon.
        if self.cfg.get("moon_motion", True):
            self.moon_x += self.moon_dir * 0.8
            if self.moon_x > w-28 or self.moon_x < 28: self.moon_dir *= -1
        mx=int(self.moon_x); my=23
        self.star_canvas.create_oval(mx-10,my-10,mx+10,my+10,fill="#f7e7b0",outline="",tags="sky")
        self.star_canvas.create_oval(mx-3,my-13,mx+13,my+7,fill=self.bg,outline=self.bg,tags="sky")
        palette=(self.accent,"#8d83b7","#ffffff")
        updated=[]
        for x,y,r,phase,speed in self.stars:
            x += speed
            if x < 3: x=w-3
            if x > w-3: x=3
            updated.append((x,y,r,phase,speed))
            bright=(int(self.star_phase/3+phase)%9)
            color=palette[0] if bright in (0,1) else palette[1] if bright in (2,3,4,5) else palette[2]
            self.star_canvas.create_rectangle(x-r,y-r,x+r,y+r,fill=color,outline="",tags="sky")
            if r==2 and bright==0:
                self.star_canvas.create_line(x-4,y,x+4,y,fill=color,tags="sky")
                self.star_canvas.create_line(x,y-4,x,y+4,fill=color,tags="sky")
        self.stars=updated
        self.root.after(80,self._animate_stars)

    def _button(self,parent,text,command,**kw):
        return tk.Button(parent,text=text,command=command,bg="#292541",fg=self.fg,activebackground="#514477",activeforeground="white",bd=0,cursor="hand2",font=(self.cfg["font"],9),**kw)

    def _bind_drag(self,widget):
        if not isinstance(widget,(tk.Button,tk.Entry,tk.Spinbox,tk.Scale,tk.Checkbutton)):
            widget.bind("<ButtonPress-1>",self._drag_start); widget.bind("<B1-Motion>",self._drag_move)
        for child in widget.winfo_children(): self._bind_drag(child)
    def _drag_start(self,event): self.drag=(event.x_root-self.root.winfo_x(),event.y_root-self.root.winfo_y())
    def _drag_move(self,event):
        if self.cfg["borderless"]: self.root.geometry(f"+{event.x_root-self.drag[0]}+{event.y_root-self.drag[1]}")
    def _hotkey_space(self,event):
        if isinstance(self.root.focus_get(),(tk.Entry,tk.Spinbox)): return
        self.start_pause(); return "break"
    def _hotkey_reset(self,event):
        if isinstance(self.root.focus_get(),(tk.Entry,tk.Spinbox)): return
        self.reset(); return "break"

    def switch_mode(self,mode):
        self.running=False; self.deadline=None; self.mode=mode
        if mode=="pomo": self.pomo_phase="专注"; self.remaining=int(self.cfg["work_min"])*60
        elif mode=="countdown": self.remaining=5*60
        elif mode=="stopwatch": self.sw_elapsed=0.0; self.sw_started=None; self.laps=[]
        self.start_btn.config(text="开始"); self._refresh_mode_buttons()
        if mode=="stopwatch": self.lap_btn.pack(side="left",padx=5)
        else: self.lap_btn.pack_forget()
        self.update_display()
    def _refresh_mode_buttons(self):
        for mode,b in self.mode_buttons.items(): b.config(bg="#443866" if self.mode==mode else "#292541")

    def quick_countdown(self,minutes):
        self.switch_mode("countdown"); self.remaining=minutes*60; self.update_display(); self.start_pause()

    def set_duration(self):
        if self.mode=="clock": self.switch_mode("countdown")
        val=simpledialog.askinteger("设置时间","请输入倒计时分钟数（1–999）",parent=self.root,minvalue=1,maxvalue=999,initialvalue=max(1,self.remaining//60))
        if val is not None:
            self.running=False; self.remaining=val*60; self.deadline=None; self.start_btn.config(text="开始"); self.update_display()

    def start_pause(self):
        if self.mode=="clock": self.switch_mode("countdown"); self.set_duration(); return
        if self.mode=="stopwatch":
            if self.running: self.sw_elapsed += time.monotonic()-self.sw_started; self.sw_started=None; self.running=False; self.start_btn.config(text="继续")
            else: self.sw_started=time.monotonic(); self.running=True; self.start_btn.config(text="暂停")
            self.update_display(); return
        if self.running: self.running=False; self.deadline=None; self.start_btn.config(text="继续")
        else:
            if self.remaining<=0: self.reset()
            self.running=True; self.deadline=time.monotonic()+self.remaining; self.start_btn.config(text="暂停")
        self.update_display()
    def reset(self):
        self.running=False; self.deadline=None
        if self.mode=="stopwatch": self.sw_elapsed=0.0; self.sw_started=None; self.laps=[]
        if self.mode=="pomo": self.remaining=int(self.cfg["work_min"])*60; self.pomo_phase="专注"
        elif self.mode=="countdown": self.remaining=5*60
        self.start_btn.config(text="开始"); self.update_display()

    def record_lap(self):
        if self.mode != "stopwatch": return
        elapsed=self.sw_elapsed + (time.monotonic()-self.sw_started if self.running and self.sw_started else 0)
        self.laps.append(elapsed)
        self.sub.config(text=f"已记录 {len(self.laps)} 次 · 最近一圈 {self._format_stopwatch(elapsed)}")

    def _format_stopwatch(self, value):
        cs=int(value*100); h=cs//360000; m=(cs//6000)%60; sec=(cs//100)%60; cent=cs%100
        return f"{h:02d}:{m:02d}:{sec:02d}.{cent:02d}"

    def _beep(self):
        if not self.cfg.get("sound", True): return
        try:
            import winsound; winsound.MessageBeep(winsound.MB_ICONASTERISK)
        except Exception: self.root.bell()
    def _complete(self):
        self.running=False; self.remaining=0; self.deadline=None; self.start_btn.config(text="开始"); self._beep()
        if self.mode=="pomo":
            if self.pomo_phase=="专注":
                self.pomo_round+=1; self.pomo_phase="长休息" if self.pomo_round%4==0 else "短休息"
                mins=int(self.cfg["long_min"] if self.pomo_phase=="长休息" else self.cfg["short_min"])
            else: self.pomo_phase="专注"; mins=int(self.cfg["work_min"])
            self.remaining=mins*60
            messagebox.showinfo("CATIME · 时间到",f"当前阶段结束！下一阶段：{self.pomo_phase}（{mins} 分钟）",parent=self.root)
            if self.cfg.get("auto_start_break"): self.running=True; self.deadline=time.monotonic()+self.remaining; self.start_btn.config(text="暂停")
        else: messagebox.showinfo("CATIME · 时间到","倒计时已结束。",parent=self.root)

    def update_display(self):
        if self.mode=="clock":
            now=time.localtime(); self.display.config(text=time.strftime("%H:%M:%S",now)); self.sub.config(text=time.strftime("%Y年%m月%d日  ·  %A",now))
        elif self.mode=="stopwatch":
            elapsed=self.sw_elapsed + (time.monotonic()-self.sw_started if self.running and self.sw_started else 0)
            self.display.config(text=self._format_stopwatch(elapsed)); self.sub.config(text=f"STOPWATCH  ·  已记录 {len(self.laps)} 次")
        else:
            s=max(0,self.remaining); self.display.config(text=f"{s//3600:02d}:{(s%3600)//60:02d}:{s%60:02d}")
            label=self.pomo_phase if self.mode=="pomo" else "倒计时"
            self.sub.config(text=f"{label}  ·  已完成 {self.pomo_round} 轮" if self.mode=="pomo" else "COUNTDOWN  ·  专注当下")
        self.status.config(text="● RUNNING" if self.running else "● READY",fg="#8cdbbf" if self.running else "#8b83a5")

    def _check_alarms(self):
        now=time.strftime("%H:%M")
        if now!=self.last_minute: self.alarm_fired.clear(); self.last_minute=now
        for alarm in self.cfg["alarms"]:
            key=f"{alarm.get('time')}|{alarm.get('name')}"
            if alarm.get("enabled",True) and alarm.get("time")==now and key not in self.alarm_fired:
                self.alarm_fired.add(key); self._beep(); messagebox.showinfo("CATIME · 闹钟",alarm.get("name") or "时间到了！",parent=self.root)

    def tick(self):
        if self.running and self.deadline is not None:
            self.remaining=max(0,int(self.deadline-time.monotonic()+0.999))
            if self.remaining<=0: self._complete()
        self.update_display(); self._check_alarms(); self.root.after(50 if self.mode=="stopwatch" else 200,self.tick)

    def presets(self):
        win=tk.Toplevel(self.root); win.title("计时预设"); win.configure(bg=self.bg); win.resizable(False,False); win.transient(self.root)
        tk.Label(win,text="我的快捷计时",bg=self.bg,fg=self.fg,font=(self.cfg["font"],13,"bold")).pack(padx=18,pady=(15,8))
        lb=tk.Listbox(win,width=34,height=7,bg="#292541",fg=self.fg,selectbackground="#514477",bd=0,highlightthickness=0,font=(self.cfg["font"],10)); lb.pack(padx=18,pady=5)
        def refresh():
            lb.delete(0,"end")
            for p in self.cfg["presets"]: lb.insert("end",f"{p['name']}  ·  {p['minutes']} 分钟")
        def run_selected():
            sel=lb.curselection()
            if not sel: return
            mins=int(self.cfg["presets"][sel[0]]["minutes"]); win.destroy(); self.quick_countdown(mins)
        def add():
            name=simpledialog.askstring("新增预设","预设名称：",parent=win)
            if not name: return
            mins=simpledialog.askinteger("新增预设","时长（分钟，1–999）：",parent=win,minvalue=1,maxvalue=999)
            if mins is None: return
            self.cfg["presets"].append({"name":name[:24],"minutes":mins}); save_config(self.cfg); refresh()
        def delete():
            sel=lb.curselection()
            if sel: self.cfg["presets"].pop(sel[0]); save_config(self.cfg); refresh()
        row=tk.Frame(win,bg=self.bg); row.pack(pady=10)
        self._button(row,"使用",run_selected,padx=13,pady=6).pack(side="left",padx=3); self._button(row,"新增",add,padx=13,pady=6).pack(side="left",padx=3); self._button(row,"删除",delete,padx=13,pady=6).pack(side="left",padx=3)
        refresh()

    def alarms(self):
        win=tk.Toplevel(self.root); win.title("闹钟管理"); win.configure(bg=self.bg); win.resizable(False,False); win.transient(self.root)
        tk.Label(win,text="每日闹钟 · 24 小时制",bg=self.bg,fg=self.fg,font=(self.cfg["font"],13,"bold")).pack(padx=18,pady=(15,8))
        lb=tk.Listbox(win,width=34,height=7,bg="#292541",fg=self.fg,selectbackground="#514477",bd=0,highlightthickness=0,font=(self.cfg["font"],10)); lb.pack(padx=18,pady=5)
        def refresh():
            lb.delete(0,"end")
            for a in self.cfg["alarms"]: lb.insert("end",f"{'开启' if a.get('enabled',True) else '关闭'}  {a['time']}  ·  {a.get('name','闹钟')}")
        def add():
            t=simpledialog.askstring("新增闹钟","时间（HH:MM，例如 08:30）：",parent=win)
            if not t: return
            try:
                hh,mm=map(int,t.split(':')); assert 0<=hh<=23 and 0<=mm<=59
            except Exception: messagebox.showerror("格式错误","请按 HH:MM 输入，例如 08:30。",parent=win); return
            name=simpledialog.askstring("闹钟名称","名称（可留空）：",parent=win) or "闹钟"
            self.cfg["alarms"].append({"time":f"{hh:02d}:{mm:02d}","name":name[:30],"enabled":True}); save_config(self.cfg); refresh()
        def toggle():
            sel=lb.curselection()
            if sel: a=self.cfg["alarms"][sel[0]]; a["enabled"]=not a.get("enabled",True); save_config(self.cfg); refresh()
        def delete():
            sel=lb.curselection()
            if sel: self.cfg["alarms"].pop(sel[0]); save_config(self.cfg); refresh()
        row=tk.Frame(win,bg=self.bg); row.pack(pady=10)
        for label,fn in [("新增",add),("启用/停用",toggle),("删除",delete)]: self._button(row,label,fn,padx=10,pady=6).pack(side="left",padx=3)
        refresh()

    def settings(self):
        win=tk.Toplevel(self.root); win.title("CATIME 设置"); win.configure(bg=self.bg); win.resizable(False,False); win.transient(self.root); win.grab_set()
        body=tk.Frame(win,bg=self.bg,padx=20,pady=16); body.pack()
        tk.Label(body,text="外观与番茄钟",bg=self.bg,fg=self.fg,font=(self.cfg["font"],14,"bold")).grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,12))
        top=tk.BooleanVar(value=self.cfg["topmost"]); border=tk.BooleanVar(value=self.cfg["borderless"]); auto=tk.BooleanVar(value=self.cfg["auto_start_break"]); sound=tk.BooleanVar(value=self.cfg.get("sound",True)); startup=tk.BooleanVar(value=self.cfg.get("startup",False)); moon=tk.BooleanVar(value=self.cfg.get("moon_motion",True)); theme=tk.StringVar(value=self.cfg.get("theme","星夜紫"))
        for r,(txt,var) in enumerate([("窗口始终置顶",top),("无边框悬浮窗口",border),("阶段结束后自动开始下一阶段",auto),("结束提示音",sound),("Windows 开机启动",startup),("月亮缓慢移动动画",moon)],1):
            tk.Checkbutton(body,text=txt,variable=var,bg=self.bg,fg=self.fg,selectcolor="#292541",activebackground=self.bg,activeforeground=self.fg).grid(row=r,column=0,columnspan=2,sticky="w",pady=4)
        tk.Label(body,text="界面主题",bg=self.bg,fg=self.fg).grid(row=7,column=0,sticky="w",pady=6)
        tk.OptionMenu(body,theme,*THEMES.keys()).grid(row=7,column=1,sticky="ew")
        alpha=tk.DoubleVar(value=self.cfg["alpha"]); size=tk.IntVar(value=self.cfg["font_size"])
        tk.Label(body,text="窗口透明度",bg=self.bg,fg=self.fg).grid(row=7,column=0,sticky="w",pady=6)
        tk.Scale(body,from_=.55,to=1.0,resolution=.05,orient="horizontal",variable=alpha,bg=self.bg,fg=self.fg,highlightthickness=0,troughcolor="#514477").grid(row=8,column=1)
        tk.Label(body,text="显示字号",bg=self.bg,fg=self.fg).grid(row=9,column=0,sticky="w",pady=6)
        tk.Spinbox(body,from_=20,to=60,textvariable=size,width=6,bg="#292541",fg=self.fg,buttonbackground="#514477").grid(row=9,column=1,sticky="w")
        def color(key):
            c=colorchooser.askcolor(self.cfg[key],parent=win)[1]
            if c: self.cfg[key]=c
        self._button(body,"选择文字颜色",lambda:color("text"),padx=10,pady=6).grid(row=10,column=0,pady=7,sticky="w")
        self._button(body,"选择强调色",lambda:color("accent"),padx=10,pady=6).grid(row=10,column=1,pady=7,sticky="w")
        def save():
            self.cfg.update(topmost=top.get(),borderless=border.get(),auto_start_break=auto.get(),sound=sound.get(),alpha=alpha.get(),font_size=size.get(),startup=startup.get(),theme=theme.get(),moon_motion=moon.get())
            self.cfg.update(THEMES[theme.get()])
            if sys.platform == "win32":
                try: set_windows_startup(startup.get())
                except Exception as exc: messagebox.showwarning("开机启动设置失败",str(exc),parent=win)
            elif startup.get():
                messagebox.showinfo("提示","开机启动仅支持 Windows。",parent=win)
            save_config(self.cfg); win.destroy(); self.root.destroy(); new=tk.Tk(); Catime(new); new.mainloop()
        self._button(body,"选择星空背景图片",self.choose_wallpaper,padx=10,pady=6).grid(row=11,column=0,pady=5,sticky="w")
        self._button(body,"恢复默认星空",self.clear_wallpaper,padx=10,pady=6).grid(row=11,column=1,pady=5,sticky="w")
        self._button(body,"保存设置",save,padx=25,pady=8).grid(row=12,column=0,columnspan=2,pady=(12,0))

    def close(self): save_config(self.cfg); self.root.destroy()

if __name__=="__main__":
    root=tk.Tk(); Catime(root); root.mainloop()
